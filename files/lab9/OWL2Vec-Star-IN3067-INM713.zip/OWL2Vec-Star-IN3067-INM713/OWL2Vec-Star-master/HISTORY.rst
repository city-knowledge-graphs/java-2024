=======
History
=======

0.2.0 (2021-08-04)
------------------

* First release on PyPI.
