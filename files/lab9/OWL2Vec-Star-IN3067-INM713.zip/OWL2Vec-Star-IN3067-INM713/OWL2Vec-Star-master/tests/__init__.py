"""Unit test package for owl2vec_star."""
